import unittest
from .test_equations import *

unittest.main()

# vim: fdm=indent
